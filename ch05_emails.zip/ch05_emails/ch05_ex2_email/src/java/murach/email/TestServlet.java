/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package murach.email;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import murach.business.User;
import murach.data.UserDB;
/**
 *
 * @author csmith119
 */
@WebServlet(urlPatterns={"/test"}, 
        initParams={@WebInitParam(name="relativePathToFile", 
                value="/WEB-INF/EmailList.txt")
})
public class TestServlet extends HttpServlet{
     @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().println("TestServlet Post");
    }
     @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().println("TestServlet Get");
    }
    
}
